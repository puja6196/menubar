package com.nucleus.model;

import javax.persistence.Entity;
import javax.persistence.Id;


@Entity
public class AuthorityPuja
{
	
	@Id
	private String role;

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Override
	public String toString() {
		return "AuthorityPuja [role=" + role + "]";
	}
	
	
}
