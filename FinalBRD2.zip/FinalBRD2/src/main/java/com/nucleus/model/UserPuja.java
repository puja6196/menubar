package com.nucleus.model;

import javax.persistence.Entity;

import javax.persistence.Id;
import javax.persistence.ManyToOne;


@Entity
public class UserPuja
{
	@Id
	
	private String userName;
	private String password;
	private int enabled;
    @ManyToOne
	private AuthorityPuja role;
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getEnabled() {
		return enabled;
	}
	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}
	@Override
	public String toString() {
		return "User [userName=" + userName + ", password=" + password + ", enabled=" + enabled
				+ "]";
	}
	
	
	
	

}
