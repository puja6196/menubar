package com.nucleus.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.nucleus.domain.Customer;
import com.nucleus.service.CustomerService;

@Controller
public class CustomerController 
{
	@Autowired
	CustomerService customerService;
	
	
	
	@RequestMapping("/menubar")
	public String requestHandler5()
	{
		return "Split";
	}
	
	@RequestMapping("/menuindex")
	public String requestHandler9()
	{
		return "MenuBar";
	}
	/*@RequestMapping("/viewall")
	public String requestHandler11()
	{
		return "ViewAll";
	}*/
	
	/*@RequestMapping("/menubar")
	public String handler0(Customer customer)
	{
		return "MenuBar";
	}*/
	@RequestMapping("/admin")
	public String handler01(Customer customer)
	{
		return "Admin";
	}
	@RequestMapping("/CustomerReg")
	public String handler2(Customer customer)
	{
		return "CustomerRegistration";
	}	
	@RequestMapping("/customersubmit")
	public ModelAndView handler3(@Valid Customer customer,BindingResult result)
	{
		if(result.hasErrors())
		{
			return new ModelAndView("CustomerRegistration");
		}
		customerService.save(customer);
		return new ModelAndView("success");
	}
	//=================================================delete===============================================
	
	@RequestMapping("/Delete")
	public String handler4(Customer customer)
	{ 
		//System.out.println("hello");
		return "Delete";
	}    
	@RequestMapping("/delete")
	public  ModelAndView handler5(@RequestParam("customerCode")String customercode)
	{
		customerService.delete(customercode);
		return new ModelAndView("success");
	}
	//=====================================================view==============================================
	
	@RequestMapping("/ViewRecord")
	public String handler7(Customer customer)
	{ 
		return "ViewRecord";
		
	}
	@RequestMapping("/viewrecord")
	public  ModelAndView handler8(@RequestParam("customerCode")String customercode)
	{
		Customer b=customerService.showRecord(customercode);
		return new ModelAndView("View","c",b);
	}
	//================================================view all================================================
	
	@RequestMapping("/View")
	public ModelAndView handler6()
	{ 
		
		List<Customer> list=customerService.show();
		return new ModelAndView("ViewAll","c",list);
	}
	//=============================================update===================================================
	
	@RequestMapping("/Update")
	public String handler9(Customer customer)
	{ 
		return "UpdateRecord";
		
	}
	@RequestMapping("/updaterecord")
	public  ModelAndView handler10(@RequestParam("customerCode")String customercode)
	{
		System.out.println("ccccc");
		Customer ab=customerService.showRecord(customercode);
		System.out.println("*************  "+ab);
		return new ModelAndView("UpdateForm","c",ab);
	}
	@RequestMapping("/UpdateRecord")
	public  ModelAndView handler11(Customer customer)
	{
		System.out.println("aaaaaaaaaaaa");
		Customer ab=customerService.updateRecord(customer);
		return new ModelAndView("View","c",ab);
	}
}
