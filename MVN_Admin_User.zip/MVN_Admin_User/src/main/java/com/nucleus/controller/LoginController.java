package com.nucleus.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class LoginController 
{
	@RequestMapping("/accdenied")
	public String RequestHandler0()
	{
		return "accessdenied";
	}
	
	@RequestMapping("/login")
	public String RequestHandler1()
	{
		return "login";
	}
	
	@RequestMapping("/loginfailure")
	public ModelAndView Requesthandler2()
	{
		return new ModelAndView("login","error","Bad Credentials");
	}
	
	@RequestMapping("/logout")
	public String RequestHandler3()
	{
		return "Logout";
	}
	
	@RequestMapping("/defaultpage")
	public String Requesthandler4(HttpServletRequest request)
	{
		String targeturl=null;
		if(request.isUserInRole("ROLE_USER"))
			targeturl="redirect:/menubar";
		else if(request.isUserInRole("ROLE_ADMIN"))
			targeturl="redirect:/admin";
		else
			targeturl="redirect:/";
		
		return targeturl;
	}
}
