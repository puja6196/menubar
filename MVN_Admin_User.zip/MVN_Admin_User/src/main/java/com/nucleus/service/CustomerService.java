package com.nucleus.service;

import java.util.List;

import com.nucleus.domain.Customer;

public interface CustomerService 
{
	public void save(Customer customer);
	public void delete(String customercode);
	public List<Customer> show();
	public Customer showRecord(String customercode);
	public Customer updateRecord(Customer customer);
}
