package com.nucleus.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nucleus.dao.User.CustomerDao;
import com.nucleus.domain.Customer;

@Service
public class CustomerServiceImpl implements CustomerService
{
	@Autowired
	CustomerDao customerDao;

	@Override
	public void save(Customer customer)
	{
		customerDao.save(customer);
	}

	@Override
	public void delete(String customercode) 
	{
		customerDao.delete(customercode);
	}

	@Override
	public List<Customer> show() 
	{
		return customerDao.show();
	}

	@Override
	public Customer showRecord(String customercode) 
	{
		return customerDao.showRecord(customercode);
	}

	@Override
	public Customer updateRecord(Customer customer) 
	{
		return customerDao.updateRecord(customer);
	}
	
}
