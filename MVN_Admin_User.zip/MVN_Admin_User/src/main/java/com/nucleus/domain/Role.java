package com.nucleus.domain;

import javax.persistence.Entity;
import javax.persistence.Table;

@Table(name="roleps")
@Entity
public class Role 
{
	private String username;
	private String role;
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	
}
