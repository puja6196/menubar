package com.nucleus.domain;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.Length;
import org.springframework.format.annotation.DateTimeFormat;

@Entity 
@Table(name="pranjalicustomertable01")
public class Customer implements Serializable
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	@Id	
	@NotNull	
	@Pattern(regexp ="^[0-9a-zA-Z]*$")
	@Length(min=1,max=10)
	String customerCode; 
	@NotNull
	@Pattern(regexp ="^[0-9a-zA-Z]*$")
	@Length(min=1,max=30)
	private String customerName ;
	@NotNull
	private String customerAddress1 ;
	@NotNull
	//@NumberFormat
	@Pattern(regexp ="^[0-9]*$")
	@Length(min=6,max=6)
	private String customerPinCode ;
	@Email
	private String emailaddress;
	//@NumberFormat
	@Pattern(regexp ="^[0-9]*$")
	@Length(min=10,max=10)
	private String contactNumber; 
	@DateTimeFormat
	private String createDate; 
	private String createdBy ;
	@DateTimeFormat
	private String modifiedDate ;
	
	
	public String getCustomerCode() {
		return customerCode;
	}
	public void setCustomerCode(String customerCode) {
		this.customerCode = customerCode;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerAddress1() {
		return customerAddress1;
	}
	public void setCustomerAddress1(String customerAddress1) {
		this.customerAddress1 = customerAddress1;
	}
	public String getCustomerPinCode() {
		return customerPinCode;
	}
	public void setCustomerPinCode(String customerPinCode) {
		this.customerPinCode = customerPinCode;
	}
	public String getEmailaddress() {
		return emailaddress;
	}
	public void setEmailaddress(String emailaddress) {
		this.emailaddress = emailaddress;
	}
	public String getContactNumber() {
		return contactNumber;
	}
	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}
	public String getCreateDate() {
		return createDate;
	}
	public void setCreateDate(String createDate) {
		this.createDate = createDate;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getModifiedDate() {
		return modifiedDate;
	}
	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
