package com.nucleus.dao.admin;

import org.springframework.stereotype.Repository;

import com.nucleus.domain.User;

@Repository
public class AdminDaoImpl 
{
	public void save(User user)
	{
		
	}
}
