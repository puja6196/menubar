package com.nucleus.dao.User;

import java.text.SimpleDateFormat;
import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.nucleus.domain.Customer;

@Repository
public class CustomerDaoImpl implements CustomerDao
{
	@Autowired
	SessionFactory sessionFactory;

	//=======================================SAVE======================================================
	@Transactional
	@Override
	public void save(Customer customer) 
	{
		customer.setCreateDate(new SimpleDateFormat("dd/MMM/YYYY").format(new java.util.Date()));
		customer.setCreatedBy("pranjali");
		sessionFactory.getCurrentSession().save(customer);
	}
	
	//===========================================DELETE=====================================================
	@Transactional
	@Override
	public void delete(String customercode) 
	{
		System.out.println(customercode);
		Customer customer1=(Customer) sessionFactory.getCurrentSession().load(Customer.class,customercode);
		if(customer1 !=null)
		{
			this.sessionFactory.getCurrentSession().delete(customer1);
		}
	}
	
	//========================================VIEW ALL======================================================
	@SuppressWarnings("unchecked")
	@Transactional
	@Override
	public List<Customer> show() 
	{		
		List<Customer> list1=sessionFactory.getCurrentSession().createQuery("from Customer").list();
		return list1;
	}

	//=====================================SINGLE VIEW=======================================================
	@Transactional
	@Override
	public Customer showRecord(String customercode) 
	{
		System.out.println(customercode);
		Customer customer2=(Customer) sessionFactory.getCurrentSession().get(Customer.class, customercode);
		return customer2;
	}

	//===================================UPDATE=============================================================
	
	@Transactional
	@Override
	public Customer updateRecord(Customer customer) 
	{
		System.out.println("bbbbbbb");
		customer.setModifiedDate(new SimpleDateFormat("dd/MMM/YYYY").format(new java.util.Date()));
		sessionFactory.getCurrentSession().update(customer);
		return customer;
	}
}
